/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiculo;

/**
 *
 * @author Aleh
 */
import javax.swing.*;

public class Ventana extends JFrame {

    public PanelRuta panelRuta;

    public Ventana(String tipoVehiculo) {

        setTitle("Ruta del Vehículo");

        setSize(700, 500);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        panelRuta =
                new PanelRuta(tipoVehiculo);

        add(panelRuta);

        setVisible(true);
    }
}