/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiculo;

/**
 *
 * @author Aleh
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelRuta extends JPanel {
    private Image fondo;
    private Image vehiculo;
    private int posicion = 0;
    private int[][] puntos;
    private Timer timer;
    
    private double xActual, yActual;
    private double dx, dy;
    private int pasos = 20;
    private int pasoActual = 0;

    public PanelRuta(String tipoVehiculo) {
        String tipo = tipoVehiculo.toLowerCase();
        setPreferredSize(new Dimension(700, 500));

        String carpetaImagenes = "C:\\Users\\Aleh\\Documents\\NetBeansProjects\\Vehiculo\\src\\main\\resources\\";

        fondo = new ImageIcon(carpetaImagenes + "mapa_" + tipo + ".jpg").getImage();
        vehiculo = new ImageIcon(carpetaImagenes + tipo + "_icono.png").getImage();

        if (tipo.equals("drone")) {
            puntos = new int[][]{{80,100}, {250,100}, {400,150}, {550,250}, {600,350}};
        } else if (tipo.equals("carro")) {
            puntos = new int[][]{{100,400}, {250,400}, {250,250}, {500,250}, {600,150}};
        } else {
            puntos = new int[][]{{120,100}, {300,180}, {420,180}, {550,320}, {600,400}};
        }
        
        xActual = puntos[0][0];
        yActual = puntos[0][1];

        timer = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moverVehiculo();
            }
        });
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (fondo != null) g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);

        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.setColor(Color.BLUE);

        for (int i = 0; i < puntos.length - 1; i++) {
            g2.drawLine(puntos[i][0], puntos[i][1], puntos[i+1][0], puntos[i+1][1]);
        }

        g2.setColor(Color.RED);
        for (int[] punto : puntos) {
            g2.fillOval(punto[0] - 6, punto[1] - 6, 12, 12);
        }

        if (vehiculo != null) {
            g.drawImage(vehiculo, (int)xActual - 20, (int)yActual - 20, 40, 40, this);
        }
    }

    // He mantenido el nombre original para que no se rompa nada
    public void moverVehiculo() {
        if (posicion < puntos.length - 1) {
            if (pasoActual == 0) {
                dx = (puntos[posicion+1][0] - puntos[posicion][0]) / (double) pasos;
                dy = (puntos[posicion+1][1] - puntos[posicion][1]) / (double) pasos;
            }

            xActual += dx;
            yActual += dy;
            pasoActual++;

            if (pasoActual >= pasos) {
                posicion++;
                pasoActual = 0;
            }
            repaint();
        } else {
            timer.stop();
        }
    }
}