/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiculo;

/**
 *
 * @author Aleh
 */


public class Drone extends Vehiculo {

    private String tipoDrone;

    private double cargaMaximaDrone;

    private boolean pilotoCertificadoDelivery;

    private boolean droneRegistrado;

    private double bateriaDisponible;

    private double costoPorKm = 2000;

    public Drone(String nombreVehiculo,
                  double pesoPaquete,
                  double tiempoRecorrido,
                  double distanciaKm,
                  double costoBase,
                  String tipoDrone,
                  double cargaMaximaDrone,
                  boolean pilotoCertificadoDelivery,
                  boolean droneRegistrado,
                  double bateriaDisponible) {

        super(nombreVehiculo,
                pesoPaquete,
                tiempoRecorrido,
                distanciaKm,
                costoBase);

        this.tipoDrone = tipoDrone;
        this.cargaMaximaDrone = cargaMaximaDrone;
        this.pilotoCertificadoDelivery =
                pilotoCertificadoDelivery;

        this.droneRegistrado = droneRegistrado;

        this.bateriaDisponible = bateriaDisponible;
    }

    @Override
    public boolean validarCondicionesEntrega() {

        if (!pilotoCertificadoDelivery)
            return false;

        if (!droneRegistrado)
            return false;

        if (pesoPaquete > cargaMaximaDrone)
            return false;

        if (bateriaDisponible < 20)
            return false;

        if (tiempoRecorrido > 60)
            return false;

        if (!tipoDrone.equalsIgnoreCase("Delivery"))
            return false;

        return true;
    }

    @Override
    public double calcularCostoServicio() {

        double costoTecnologico = 10000;

        double adicionalBateria = 0;

        if (bateriaDisponible < 50) {

            adicionalBateria = 5000;
        }

        return costoBase +
                (distanciaKm * costoPorKm) +
                costoTecnologico +
                adicionalBateria;
    }
}