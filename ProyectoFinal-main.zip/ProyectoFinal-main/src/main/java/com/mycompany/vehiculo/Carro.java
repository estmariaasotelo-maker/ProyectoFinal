/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiculo;

/**
 *
 * @author Aleh
 */
public class Carro extends Vehiculo {

    private double costoPorKm = 1500;

    public Carro(String nombreVehiculo,
                  double pesoPaquete,
                  double tiempoRecorrido,
                  double distanciaKm,
                  double costoBase) {

        super(nombreVehiculo,
                pesoPaquete,
                tiempoRecorrido,
                distanciaKm,
                costoBase);
    }

    @Override
    public boolean validarCondicionesEntrega() {

        return pesoPaquete <= 50;
    }

    @Override
    public double calcularCostoServicio() {

        double adicionalPeso = 0;

        if (pesoPaquete > 30) {

            adicionalPeso = 5000;
        }

        return costoBase +
                (distanciaKm * costoPorKm) +
                adicionalPeso;
    }
}