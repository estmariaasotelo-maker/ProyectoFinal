/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiculo;

/**
 *
 * @author Aleh
 */
// ==========================================
import javax.swing.*;
import java.awt.*;

public class SistemaDelivery extends JFrame {

    private JComboBox<String> comboVehiculo;
    private JTextField txtPeso, txtDistancia, txtTiempo;
    private JTextField txtTipoDrone, txtCargaMax, txtBateria;
    private JCheckBox chkPiloto, chkRegistrado;
    private JTextArea txtResultado;
    private JButton btnCalcular, btnArriba, btnAbajo, btnIzquierda, btnDerecha;
    
    private int fila = 0;
    private int columna = 0;
    private int tiempoRestante = 0;
    private boolean servicioActivo = false;
    private String infoServicio = "";
    private Ventana ventanaRuta;

    public SistemaDelivery() {
        setTitle("Sistema Delivery");
        setSize(650, 750);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Asegúrate de que Diseño.FONDO esté definido en tu clase Diseño
        getContentPane().setBackground(Diseño.FONDO); 

        iniciarComponentes();
    }

    private void iniciarComponentes() {
        // --- Etiquetas y campos ---
        JLabel lblVehiculo = new JLabel("Vehículo:");
        lblVehiculo.setBounds(20, 20, 100, 25);
        add(lblVehiculo);

        comboVehiculo = new JComboBox<>(new String[]{"Carro", "Moto", "Drone"});
        comboVehiculo.setBounds(120, 20, 150, 25);
        add(comboVehiculo);

        txtPeso = new JTextField(); txtDistancia = new JTextField(); txtTiempo = new JTextField();
        txtTipoDrone = new JTextField(); txtCargaMax = new JTextField(); txtBateria = new JTextField();

        txtPeso.setBounds(120, 70, 150, 25);
        txtDistancia.setBounds(120, 110, 150, 25);
        txtTiempo.setBounds(120, 150, 150, 25);
        txtTipoDrone.setBounds(430, 70, 150, 25);
        txtCargaMax.setBounds(430, 110, 150, 25);
        txtBateria.setBounds(430, 150, 150, 25);

        add(txtPeso); add(txtDistancia); add(txtTiempo);
        add(txtTipoDrone); add(txtCargaMax); add(txtBateria);

        add(new JLabel("Peso (Kg)")).setBounds(20, 70, 100, 25);
        add(new JLabel("Distancia (Km)")).setBounds(20, 110, 100, 25);
        add(new JLabel("Tiempo (Min)")).setBounds(20, 150, 100, 25);
        add(new JLabel("Tipo Drone")).setBounds(320, 70, 100, 25);
        add(new JLabel("Carga Máx")).setBounds(320, 110, 100, 25);
        add(new JLabel("Batería")).setBounds(320, 150, 100, 25);

        chkPiloto = new JCheckBox("Piloto Certificado");
        chkRegistrado = new JCheckBox("Drone Registrado");
        chkPiloto.setBounds(320, 190, 200, 25);
        chkRegistrado.setBounds(320, 220, 200, 25);
        add(chkPiloto); add(chkRegistrado);

        // --- Botones ---
        btnCalcular = new JButton("Iniciar Servicio");
        btnCalcular.setBounds(200, 270, 220, 40);
        btnCalcular.setBackground(Diseño.BOTON);
        btnCalcular.setForeground(Color.WHITE);
        add(btnCalcular);

        btnArriba = new JButton("↑"); btnAbajo = new JButton("↓");
        btnIzquierda = new JButton("←"); btnDerecha = new JButton("→");

        btnArriba.setBounds(270, 340, 60, 30);
        btnAbajo.setBounds(270, 410, 60, 30);
        btnIzquierda.setBounds(190, 375, 60, 30);
        btnDerecha.setBounds(350, 375, 60, 30);

        for (JButton b : new JButton[]{btnArriba, btnAbajo, btnIzquierda, btnDerecha}) {
            b.setBackground(Diseño.BOTON); b.setForeground(Color.WHITE);
            add(b);
        }

        // --- Matriz (JTextArea) ---
        txtResultado = new JTextArea();
        txtResultado.setEditable(false);
        txtResultado.setFont(Diseño.TABLA);
        txtResultado.setBackground(Diseño.TABLA_FONDO);
        txtResultado.setForeground(Diseño.TABLA_TEXTO);
        
        JScrollPane scroll = new JScrollPane(txtResultado);
        scroll.setBounds(50, 460, 500, 200); // POSICIÓN Y TAMAÑO
        add(scroll); // AQUÍ ES DONDE LA MATRIZ APARECE EN EL FRAME

        // --- Listeners ---
        btnCalcular.addActionListener(e -> calcularServicio());
        btnArriba.addActionListener(e -> mover("ARRIBA"));
        btnAbajo.addActionListener(e -> mover("ABAJO"));
        btnIzquierda.addActionListener(e -> mover("IZQUIERDA"));
        btnDerecha.addActionListener(e -> mover("DERECHA"));
    }

    private void calcularServicio() {
        try {
            double peso = Double.parseDouble(txtPeso.getText());
            double distancia = Double.parseDouble(txtDistancia.getText());
            double tiempo = Double.parseDouble(txtTiempo.getText());
            String tipo = comboVehiculo.getSelectedItem().toString();
            Vehiculo vehiculo;

            if (tipo.equals("Carro")) vehiculo = new Carro("Carro", peso, tiempo, distancia, 10000);
            else if (tipo.equals("Moto")) vehiculo = new Moto("Moto", peso, tiempo, distancia, 5000);
            else {
                vehiculo = new Drone("Drone", peso, tiempo, distancia, 15000, txtTipoDrone.getText(), 
                                     Double.parseDouble(txtCargaMax.getText()), chkPiloto.isSelected(), 
                                     chkRegistrado.isSelected(), Double.parseDouble(txtBateria.getText()));
            }

            if (vehiculo.validarCondicionesEntrega()) {
                double costo = vehiculo.calcularCostoServicio();
                tiempoRestante = (int) tiempo;
                fila = 0; columna = 0; servicioActivo = true;
                infoServicio = "Entrega aprobada\nVehículo: " + vehiculo.getNombreVehiculo() + 
                               "\nCosto: $" + costo + "\n\n";
                mostrarMatriz();
                if (ventanaRuta != null) ventanaRuta.dispose();
                ventanaRuta = new Ventana(tipo);
                ventanaRuta.setVisible(true);
            } else {
                txtResultado.setText("NO cumple condiciones");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Complete correctamente los campos");
        }
    }

    private void mostrarMatriz() {
        String[][] matriz = new String[5][5];
        for (int i = 0; i < 5; i++) for (int j = 0; j < 5; j++) matriz[i][j] = "[ ]";
        
        if (fila == 4 && columna == 4) matriz[4][4] = "[X]";
        else { matriz[fila][columna] = "[X]"; matriz[4][4] = "[C]"; }

        StringBuilder texto = new StringBuilder(infoServicio + "Tiempo restante: " + tiempoRestante + "\n\n");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) texto.append(matriz[i][j]);
            texto.append("\n");
        }
        txtResultado.setText(texto.toString());
    }

    private void mover(String direccion) {
        if (!servicioActivo || tiempoRestante <= 0) return;
        switch (direccion) {
            case "ARRIBA": if (fila > 0) fila--; break;
            case "ABAJO": if (fila < 4) fila++; break;
            case "IZQUIERDA": if (columna > 0) columna--; break;
            case "DERECHA": if (columna < 4) columna++; break;
        }
        tiempoRestante--;
        mostrarMatriz();
        if (ventanaRuta != null) ventanaRuta.panelRuta.moverVehiculo();
        if (fila == 4 && columna == 4) {
            JOptionPane.showMessageDialog(this, "Entrega completada");
            servicioActivo = false;
        }
    }
}