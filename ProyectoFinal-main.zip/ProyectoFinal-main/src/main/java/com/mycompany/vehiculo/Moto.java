/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiculo;

/**
 *
 * @author Aleh
 */

public class Moto extends Vehiculo {

    private double costoPorKm = 800;

    public Moto(String nombreVehiculo,
                double pesoPaquete,
                double tiempoRecorrido,
                double distanciaKm,
                double costoBase) {

        super(nombreVehiculo,
                pesoPaquete,
                tiempoRecorrido,
                distanciaKm,
                costoBase);
    }

    @Override
    public boolean validarCondicionesEntrega() {

        return pesoPaquete <= 20;
    }

    @Override
    public double calcularCostoServicio() {

        return costoBase +
                (distanciaKm * costoPorKm);
    }
}