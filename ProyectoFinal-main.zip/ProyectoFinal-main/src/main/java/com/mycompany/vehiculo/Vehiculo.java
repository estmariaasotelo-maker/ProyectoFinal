/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vehiculo;

/**
 *
 * @author Aleh
 */

public abstract class Vehiculo {

    protected String nombreVehiculo;
    protected double pesoPaquete;
    protected double tiempoRecorrido;
    protected double distanciaKm;
    protected double costoBase;

    public Vehiculo() {
    }

    public Vehiculo(String nombreVehiculo,
                     double pesoPaquete,
                     double tiempoRecorrido,
                     double distanciaKm,
                     double costoBase) {

        this.nombreVehiculo = nombreVehiculo;
        this.pesoPaquete = pesoPaquete;
        this.tiempoRecorrido = tiempoRecorrido;
        this.distanciaKm = distanciaKm;
        this.costoBase = costoBase;
    }

    public void mostrarInformacion() {
    }

    public double calcularCostoServicio() {
        return costoBase;
    }

    public abstract boolean validarCondicionesEntrega();

    public String getNombreVehiculo() {
        return nombreVehiculo;
    }
}