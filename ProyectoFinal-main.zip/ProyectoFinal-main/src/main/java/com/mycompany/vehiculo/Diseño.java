/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiculo;
import java.awt.Color;
import java.awt.Font;

public class Diseño {

    public static final Color FONDO =
            new Color(245, 247, 250);

    public static final Color PANEL =
            new Color(255, 255, 255);

    public static final Color BOTON =
            new Color(52, 73, 94);

    public static final Color BOTON_HOVER =
            new Color(41, 128, 185);

    public static final Color TEXTO =
            new Color(44, 62, 80);

    public static final Color TABLA_FONDO =
            new Color(250, 252, 255);

    public static final Color TABLA_TEXTO =
            new Color(33, 37, 41);

    public static final Font TITULO =
            new Font("Segoe UI", Font.BOLD, 18);

    public static final Font NORMAL =
            new Font("Segoe UI", Font.PLAIN, 14);

    public static final Font BOTONES =
            new Font("Segoe UI", Font.BOLD, 14);

    public static final Font TABLA =
            new Font("Consolas", Font.PLAIN, 15);
}